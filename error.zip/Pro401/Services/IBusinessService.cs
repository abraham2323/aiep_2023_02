﻿namespace Pro401.Services
{
    public interface IBusinessService
    {
        bool PrimeraLetraMayuscula(string color);
    }
}
